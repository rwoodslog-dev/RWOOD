-- Notybat 5.65.0 — Ancrage serveur du traceur (à exécuter UNE fois dans Supabase › SQL Editor)
-- Principe : le téléphone envoie l'empreinte (hash) de chaque pointage ; le serveur y ajoute SA propre heure.
-- La table est en insertion seule : personne ne peut modifier ni effacer une ligne depuis l'appli.

create table if not exists public.rwood_trk_anchors (
  id         bigserial primary key,
  rwood_id   text        not null,
  day        date        not null,
  seq        int         not null default 0,
  kind       text        not null,            -- ev:depart_depot, ev:arrivee_chantier, …, cp (point de contrôle), del (suppression)
  h          text        not null,            -- empreinte SHA-256 de la chaîne
  prev       text        not null default '', -- empreinte de la veille (chaînage entre journées)
  client_t   bigint      not null,            -- heure du téléphone (ms)
  flags      jsonb       not null default '{}'::jsonb,
  server_t   timestamptz not null default now(),
  unique (rwood_id, kind, h)
);
create index if not exists rwood_trk_anchors_day on public.rwood_trk_anchors (rwood_id, day);

alter table public.rwood_trk_anchors enable row level security;
revoke all on public.rwood_trk_anchors from anon, authenticated;   -- aucun accès direct : tout passe par les 2 fonctions ci-dessous

create or replace function public.rwood_trk_anchor(
  p_rwood_id text, p_day date, p_seq int, p_kind text, p_hash text, p_prev text, p_client_t bigint, p_flags jsonb
) returns timestamptz
language plpgsql security definer set search_path = public as $$
declare t timestamptz;
begin
  insert into public.rwood_trk_anchors (rwood_id, day, seq, kind, h, prev, client_t, flags)
  values (p_rwood_id, p_day, coalesce(p_seq,0), p_kind, p_hash, coalesce(p_prev,''), p_client_t, coalesce(p_flags,'{}'::jsonb))
  on conflict (rwood_id, kind, h) do nothing;
  select server_t into t from public.rwood_trk_anchors where rwood_id = p_rwood_id and kind = p_kind and h = p_hash;
  return t;                                   -- heure du SERVEUR du premier envoi (jamais réécrite)
end $$;

create or replace function public.rwood_trk_anchors(p_rwood_id text, p_day date)
returns table (seq int, kind text, h text, prev text, client_t bigint, server_t timestamptz, flags jsonb)
language sql security definer set search_path = public as $$
  select seq, kind, h, prev, client_t, server_t, flags
  from public.rwood_trk_anchors where rwood_id = p_rwood_id and day = p_day order by id;
$$;

grant execute on function public.rwood_trk_anchor(text, date, int, text, text, text, bigint, jsonb) to anon, authenticated;
grant execute on function public.rwood_trk_anchors(text, date) to anon, authenticated;
